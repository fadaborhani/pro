( function( $ ) {
    "use strict";

    $(document).ready(function(){
        $(".codeless-multiple-select").select2();
    });

} ) ( jQuery );