# Livecast The WordPress 

## Description

Livecast a minimal and modern brutalist design for Portfolio & Creative Agency websites

## Changelog

### 1.1

Big UPDATE

Added: Compatible with all podcasts platforms (Spotify, Transistor, Buzzsprout etc...)
Fixed: CoWidget plugin update
Fixed: Staff Carousel Nav-links/buttons not working
Fixed: Codeless Shortcode ()
Fixed: Pagination on podcast grid listing
Fixed: Subscribe On on Featured Podcast Element
Fixed: Back to top button  on single podcast post 

### 1.0.4

Added: Buzzsprout iframe loading on playing button.

### 1.0.3

Added Slider Revolution Update


### 1.0.2

Fixed: Included Revslider templates
Added: Child theme

### 1.0.1

Updated: Dummy Data
Fixed: Small issues on Podcast subscribe links
Fixed: Timeline shortcode element

### 1.0

* Released: May, 2020

Initial release